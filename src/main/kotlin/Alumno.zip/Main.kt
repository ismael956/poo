fun main(args: Array<String>) {

    val pepe=Alumno("77777777U",21)
    val ana=Alumno("88888888Y",41)


    pepe.notaTrimestre1=6
    pepe.notaTrimestre2=7
    pepe.notaTrimestre3=9

    //pepe.informeAlumno()
    ana.notaTrimestre1=4
    ana.notaTrimestre2=6

    ana.informeAlumno()

}
